import json

import Transition
import Pos


def key(a):
    return a.id


class Point:
    id: int
    pos: Pos
    markers: int
    trans_in: list
    trans_out: list

    def __init__(self, id, pos, markers=-1, trans_out=None, trans_in=None):
        if trans_in is None:
            trans_in = []
        if trans_out is None:
            trans_out = []
        self.id = id
        self.pos = pos
        self.markers = markers
        self.trans_out = trans_out
        self.trans_in = trans_in

    def addLink(self, tr: Transition, in_out: bool) -> bool:
        if in_out:
            if tr not in self.trans_in:
                self.trans_in.append(tr)
                return True
            else:
                self.trans_in.append(tr)
                return False
        else:
            if tr not in self.trans_out:
                self.trans_out.append(tr)
                return True
            else:
                self.trans_out.append(tr)
                return False

    def toJSON(self):
        json_point = {'id': self.id, 'pos': [self.pos.x, self.pos.y], 'markers': self.markers}
        s = json.dumps(json_point)
        return s
