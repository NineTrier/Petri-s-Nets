import json

import Point
import Pos


def key(a):
    return a.id


def key_x(a):
    return a.pos.x


def key_len(a):
    return len(a.points_in)


class Transition:
    id: int
    pos: Pos
    points_in: list
    points_out: list

    def __init__(self, id, pos, points_in=None, points_out=None):
        if points_out is None:
            points_out = []
        if points_in is None:
            points_in = []
        self.id = id
        self.pos = pos
        self.points_in = points_in
        self.points_out = points_out

    def addLink(self, pt: Point, in_out: bool):
        if in_out:
            if pt not in self.points_in:
                self.points_in.append(pt)
                return True
            else:
                self.points_in.append(pt)
                return False
        else:
            if pt not in self.points_out:
                self.points_out.append(pt)
                return True
            else:
                self.points_out.append(pt)
                return False

    def check_for_run(self, markersGoIn):
        sum_markers = 0
        print("Markers", markersGoIn)
        for i, j in zip(self.points_in, markersGoIn):
            print(i.markers, j)
            sum_markers += i.markers if i.markers >= 0 else 1
            if i.markers < j[1]:
                return False
        if sum_markers < len(self.points_in):
            return False
        else:
            return True

    def run(self, markersGoIn: list, markersGoOut: list):
        if not self.check_for_run(markersGoIn):
            return False
        for i, j in zip(self.points_in, markersGoIn):
            if i.markers - j[1] >= 0:
                i.markers -= j[1]
        for i, j in zip(self.points_out, markersGoOut):
            if i.markers > -1:
                i.markers += j[1]
        return True

    def toJSON(self):
        json_point = {'id': self.id, 'pos': [self.pos.x, self.pos.y]}
        s = json.dumps(json_point)
        return s
